import { defineContentScript } from 'wxt/sandbox';
import { getSettings, onSettingsChange, TikTokUnhookSettings } from '@/utils/storage';
import { generateStyles } from '@/utils/selectors';

export default defineContentScript({
  matches: ['*://*.tiktok.com/*'],
  runAt: 'document_start',
  main() {
    console.log('[TikTok Unhook] Content script initialized.');

    const STYLE_ID = 'tiktok-unhook-injected-css';
    let currentSettings: TikTokUnhookSettings | null = null;
    let profileRedirectInFlight = false;

    const redirectToFollowing = () => {
      console.log('[TikTok Unhook] Redirecting to /following...');
      window.location.replace('/following');
    };

    // Profile link looks like "/@username". When not logged in, TikTok leaves empty placeholder "/@"
    const getProfileHref = (): string | null => {
      const link = document.querySelector('[data-e2e="nav-profile"]');
      const href = link?.getAttribute('href') || null;
      return href && href.startsWith('/@') && href.length > 2 ? href : null;
    };

    const redirectToProfile = () => {
      const href = getProfileHref();
      if (href) {
        console.log(`[TikTok Unhook] Redirecting to profile ${href}...`);
        window.location.replace(href);
        return;
      }

      if (profileRedirectInFlight) return;
      profileRedirectInFlight = true;
      console.log('[TikTok Unhook] Profile link (nav-profile) not yet rendered - waiting...');

      let attempts = 0;
      const MAX_ATTEMPTS = 40; // ~20s at 500ms intervals

      const intervalId = window.setInterval(() => {
        if (window.location.pathname !== '/') {
          window.clearInterval(intervalId);
          profileRedirectInFlight = false;
          return;
        }

        attempts++;
        const foundHref = getProfileHref();
        if (foundHref) {
          window.clearInterval(intervalId);
          profileRedirectInFlight = false;
          console.log(`[TikTok Unhook] Redirecting to profile ${foundHref}...`);
          window.location.replace(foundHref);
          return;
        }

        if (attempts >= MAX_ATTEMPTS) {
          window.clearInterval(intervalId);
          profileRedirectInFlight = false;
          console.warn(
            '[TikTok Unhook] Profile link (data-e2e="nav-profile") was not found after 20s. Staying on current page.'
          );
        }
      }, 500);
    };

    // 1. Auto-redirect from "For You" and "Explore"
    const handleAutoRedirect = (settings: TikTokUnhookSettings) => {
      if (!settings.masterEnabled) return;

      const path = window.location.pathname;

      if (settings.hideForYouFeed && path === '/') {
        if (settings.redirectToProfile) {
          redirectToProfile();
        } else {
          redirectToFollowing();
        }
        return;
      }

      if (settings.hideExploreFeed && path === '/explore') {
        redirectToFollowing();
      }
    };

    // 1b. Ads and "You may like" tab hiding
    const AD_LABELS = ['Ad', 'Sponsored', 'Reklama', 'Sponsorowane'];
    const RECOMMEND_TAB_LABELS = ['You may like', 'Może ci się spodobać', 'Możesz polubić'];
    const COMMENTS_TAB_LABELS = ['Comments', 'Komentarze'];
    const HIDDEN_MARK = 'data-unhook-hidden';

    const hideAdCardNear = (labelEl: Element) => {
      let node: Element | null = labelEl;
      for (let i = 0; i < 6 && node; i++) {
        if (node !== labelEl && node.querySelector('a, button')) {
          if (!node.hasAttribute(HIDDEN_MARK)) {
            (node as HTMLElement).style.display = 'none';
            node.setAttribute(HIDDEN_MARK, '1');
            console.log('[TikTok Unhook] Hidden ad block.');
          }
          return;
        }
        node = node.parentElement;
      }
    };

    const hideRecommendTab = (labelEl: Element) => {
      let tabButton: Element | null = labelEl;
      for (let i = 0; i < 3 && tabButton; i++) {
        if (tabButton.tagName === 'BUTTON' || tabButton.getAttribute('role') === 'tab') break;
        tabButton = tabButton.parentElement;
      }
      if (!tabButton || tabButton.hasAttribute(HIDDEN_MARK)) return;

      // Try switching to "Comments" tab before hiding "You may like"
      const siblings = tabButton.parentElement ? Array.from(tabButton.parentElement.children) : [];
      const commentsTab = siblings.find(
        (el) => el !== tabButton && COMMENTS_TAB_LABELS.includes((el.textContent || '').trim())
      );
      if (commentsTab instanceof HTMLElement) {
        commentsTab.click();
      }

      (tabButton as HTMLElement).style.display = 'none';
      tabButton.setAttribute(HIDDEN_MARK, '1');
      console.log('[TikTok Unhook] Hidden "You may like" tab.');
    };

    let scanScheduled = false;
    const scanForTextDistractions = (settings: TikTokUnhookSettings) => {
      if (!settings.masterEnabled || !settings.hideAds) return;

      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, {
        acceptNode: (el) => ((el as Element).children.length === 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP),
      });

      let node: Node | null;
      while ((node = walker.nextNode())) {
        const el = node as Element;
        if (el.hasAttribute(HIDDEN_MARK)) continue;
        const text = (el.textContent || '').trim();
        if (!text || text.length > 20) continue;

        if (AD_LABELS.includes(text)) {
          hideAdCardNear(el);
        } else if (RECOMMEND_TAB_LABELS.includes(text)) {
          hideRecommendTab(el);
        }
      }
    };

    // 1c. "Viral Only" filter for /following
    const VIRAL_CHECKED_MARK = 'data-unhook-viral-checked';

    const parseFormattedCount = (raw: string): number | null => {
      const text = raw.trim().toUpperCase().replace(',', '.');
      if (!text) return null;
      const match = text.match(/^([\d.]+)\s*([KMB]?)$/);
      if (!match) return null;
      const num = parseFloat(match[1]);
      if (Number.isNaN(num)) return null;
      const multiplier = match[2] === 'K' ? 1_000 : match[2] === 'M' ? 1_000_000 : match[2] === 'B' ? 1_000_000_000 : 1;
      return Math.round(num * multiplier);
    };

    const getActiveFeedCard = (): Element | null => {
      const cards = document.querySelectorAll('[data-e2e="recommend-list-item-container"]');
      let best: Element | null = null;
      let bestVisible = 0;
      cards.forEach((card) => {
        const rect = (card as HTMLElement).getBoundingClientRect();
        const visibleHeight = Math.min(rect.bottom, window.innerHeight) - Math.max(rect.top, 0);
        if (visibleHeight > bestVisible) {
          bestVisible = visibleHeight;
          best = card;
        }
      });
      return bestVisible > window.innerHeight * 0.5 ? best : null;
    };

    const scanViralFilter = (settings: TikTokUnhookSettings) => {
      if (!settings.masterEnabled || !settings.viralFilterEnabled) return;
      if (!window.location.pathname.startsWith('/following')) return;

      const card = getActiveFeedCard();
      if (!card || card.hasAttribute(VIRAL_CHECKED_MARK)) return;

      const likeEl = card.querySelector('[data-e2e="like-count"]');
      const likes = likeEl ? parseFormattedCount(likeEl.textContent || '') : null;
      if (likes === null) return;

      const commentEl = card.querySelector('[data-e2e="comment-count"]');
      const comments = commentEl ? parseFormattedCount(commentEl.textContent || '') ?? 0 : 0;

      card.setAttribute(VIRAL_CHECKED_MARK, '1');

      if (likes < settings.viralMinLikes && comments < settings.viralMinComments) {
        const nextBtn = document.querySelector('[data-e2e="feed-navigation-next"]') as HTMLElement | null;
        if (nextBtn) {
          console.log(`[TikTok Unhook] Skipping non-viral video (${likes} likes, ${comments} comments).`);
          nextBtn.click();
        }
      }
    };

    // 1d. Compact Following Panel in Sidebar
    const FOLLOWING_PANEL_ID = 'tiktok-unhook-following-panel';
    const VIEW_ALL_LABELS = ['View all', 'Zobacz wszystkie', 'Zobacz wszystkich'];
    const MAX_FOLLOWING_LIST_ATTEMPTS = 3;
    const FOLLOWING_LIST_COOLDOWN_MS = 15000;
    let followingListBuilt = false;
    let followingListBuilding = false;
    let followingListAttempts = 0;
    let followingListLastAttempt = 0;

    const waitFor = (check: () => boolean, timeoutMs: number, stepMs = 150): Promise<boolean> =>
      new Promise((resolve) => {
        const start = Date.now();
        const tick = () => {
          if (check()) return resolve(true);
          if (Date.now() - start > timeoutMs) return resolve(false);
          window.setTimeout(tick, stepMs);
        };
        tick();
      });

    const findByExactText = (labels: string[]): HTMLElement | null => {
      const candidates = document.querySelectorAll('button, div[role="button"], a');
      for (const el of Array.from(candidates)) {
        if (labels.includes((el.textContent || '').trim())) return el as HTMLElement;
      }
      return null;
    };

    const renderCompactFollowingPanel = (
      accounts: { href: string; name: string; avatar: string | null }[],
      heading: Element
    ) => {
      let sibling = heading.nextElementSibling;
      while (sibling) {
        const next = sibling.nextElementSibling;
        (sibling as HTMLElement).style.display = 'none';
        sibling.setAttribute(HIDDEN_MARK, '1');
        sibling = next;
      }

      const panel = document.createElement('div');
      panel.id = FOLLOWING_PANEL_ID;
      panel.style.cssText =
        'display:grid;grid-template-columns:repeat(auto-fill,minmax(34px,34px));gap:8px;padding:8px 4px;max-height:260px;overflow-y:auto;';

      accounts.forEach(({ href, name, avatar }) => {
        const link = document.createElement('a');
        link.href = href;
        link.title = name;
        link.style.cssText =
          'display:block;width:34px;height:34px;border-radius:50%;overflow:hidden;flex-shrink:0;background:#333;';
        if (avatar) {
          const img = document.createElement('img');
          img.src = avatar;
          img.alt = name;
          img.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;';
          link.appendChild(img);
        }
        panel.appendChild(link);
      });

      heading.insertAdjacentElement('afterend', panel);
    };

    const buildCompactFollowingPanel = async (settings: TikTokUnhookSettings) => {
      if (!settings.masterEnabled || !settings.showAllFollowingInSidebar) return;
      if (followingListBuilt && document.getElementById(FOLLOWING_PANEL_ID)) return;
      if (followingListBuilt && !document.getElementById(FOLLOWING_PANEL_ID)) followingListBuilt = false;
      if (followingListBuilding) return;
      if (followingListAttempts >= MAX_FOLLOWING_LIST_ATTEMPTS) return;
      if (Date.now() - followingListLastAttempt < FOLLOWING_LIST_COOLDOWN_MS) return;

      const heading = Array.from(document.querySelectorAll('*')).find(
        (el) => el.children.length === 0 && (el.textContent || '').trim() === 'Following accounts'
      );
      if (!heading) return;

      const viewAllBtn = findByExactText(VIEW_ALL_LABELS);
      if (!viewAllBtn) return;

      followingListBuilding = true;
      followingListAttempts++;
      followingListLastAttempt = Date.now();
      console.log(`[TikTok Unhook] Fetching full following list (attempt ${followingListAttempts}/${MAX_FOLLOWING_LIST_ATTEMPTS})...`);

      viewAllBtn.click();
      const dialogSelector = '[role="dialog"], [aria-modal="true"], [role="alertdialog"]';
      await waitFor(() => document.querySelectorAll(`${dialogSelector} a[href^="/@"]`).length > 0, 4000);
      await new Promise((r) => window.setTimeout(r, 300));

      const dialog = document.querySelector(dialogSelector);
      const links = Array.from((dialog || document).querySelectorAll('a[href^="/@"]')) as HTMLAnchorElement[];

      const seen = new Set<string>();
      const accounts: { href: string; name: string; avatar: string | null }[] = [];
      links.forEach((a) => {
        const href = a.getAttribute('href') || '';
        if (!href.startsWith('/@') || href.length <= 2 || seen.has(href)) return;
        seen.add(href);
        const img = a.querySelector('img');
        const name = (a.textContent || href.slice(2)).trim().slice(0, 40) || href.slice(2);
        accounts.push({ href, name, avatar: img?.getAttribute('src') || null });
      });

      const dispatchEscape = () => {
        const evt = new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true });
        document.dispatchEvent(evt);
        document.activeElement?.dispatchEvent(evt);
      };
      dispatchEscape();
      await new Promise((r) => window.setTimeout(r, 250));

      const stillOpen = () =>
        Array.from(document.querySelectorAll('h1,h2,h3,div,span')).some(
          (el) => el.children.length === 0 && (el.textContent || '').trim() === 'Following accounts'
        );

      if (dialog && stillOpen()) {
        const closeBtn = Array.from(dialog.querySelectorAll('button, [role="button"]')).find(
          (el) => el.querySelector('svg') && !(el.textContent || '').trim()
        );
        if (closeBtn instanceof HTMLElement) closeBtn.click();
        await new Promise((r) => window.setTimeout(r, 250));
      }

      followingListBuilding = false;

      if (accounts.length === 0) {
        return;
      }

      followingListBuilt = true;
      renderCompactFollowingPanel(accounts, heading);
      console.log(`[TikTok Unhook] Compact following list ready (${accounts.length} accounts).`);
    };

    const scheduleTextScan = (settings: TikTokUnhookSettings | null) => {
      if (!settings || scanScheduled) return;
      scanScheduled = true;
      window.setTimeout(() => {
        scanScheduled = false;
        scanForTextDistractions(settings);
        scanViralFilter(settings);
        buildCompactFollowingPanel(settings);
      }, 400);
    };

    // 2. Direct CSS Injection into DOM
    const applyCSS = (settings: TikTokUnhookSettings) => {
      currentSettings = settings;

      let styleEl = document.getElementById(STYLE_ID) as HTMLStyleElement | null;
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = STYLE_ID;
        (document.head || document.documentElement).appendChild(styleEl);
      }

      styleEl.textContent = generateStyles(settings);

      if (settings.masterEnabled) {
        document.documentElement.classList.add('unhook-active');
        if (window.location.pathname === '/' || window.location.pathname === '/foryou') {
          document.documentElement.classList.add('unhook-home-feed');
        } else {
          document.documentElement.classList.remove('unhook-home-feed');
        }
      } else {
        document.documentElement.classList.remove('unhook-active', 'unhook-home-feed');
      }

      handleAutoRedirect(settings);
      scheduleTextScan(settings);
    };

    // 3. Load initial settings
    getSettings().then((settings) => {
      applyCSS(settings);
    });

    onSettingsChange((newSettings) => {
      applyCSS(newSettings);
    });

    // 4. SPA Route Change Listener
    const onLocationChange = () => {
      if (currentSettings) {
        applyCSS(currentSettings);
      }
    };

    window.addEventListener('popstate', onLocationChange);
    window.addEventListener('hashchange', onLocationChange);

    const origPush = history.pushState;
    history.pushState = function (...args) {
      origPush.apply(this, args);
      onLocationChange();
    };

    const origReplace = history.replaceState;
    history.replaceState = function (...args) {
      origReplace.apply(this, args);
      onLocationChange();
    };

    // 5. DOM Mutation Observer
    const observer = new MutationObserver(() => {
      if (!currentSettings) return;
      if (!document.getElementById(STYLE_ID)) {
        applyCSS(currentSettings);
      }
      scheduleTextScan(currentSettings);
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
  },
});
