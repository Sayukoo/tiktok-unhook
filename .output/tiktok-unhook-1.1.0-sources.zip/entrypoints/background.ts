import { defineBackground } from 'wxt/sandbox';
import { getSettings, saveSettings, DEFAULT_SETTINGS } from '@/utils/storage';

export default defineBackground(() => {
  // Initialize default settings upon installation
  getSettings().then((current) => {
    saveSettings({ ...DEFAULT_SETTINGS, ...current });
  });
});
