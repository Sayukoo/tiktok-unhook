import { Language } from './i18n';

export interface TikTokUnhookSettings {
  // Master Switch & Appearance
  masterEnabled: boolean;
  theme: 'dark' | 'light';
  language: Language;

  // 1. Feeds & Navigation
  hideForYouFeed: boolean;
  hideExploreFeed: boolean;
  hideFollowingFeed: boolean;
  redirectToProfile: boolean; // Direct entry to personal profile instead of Following

  // 2. Sidebar & Accounts
  hideSuggestedAccounts: boolean; // Hide stranger accounts, keep Following!
  highlightFollowingAccounts: boolean; // Emphasize Following accounts
  hideLiveSidebar: boolean;
  hidePlaylists: boolean;
  hideFundraisers: boolean;
  hideSidebarFooter: boolean;

  // 3. Video, Comments & Descriptions
  hideComments: boolean;
  hideDescriptions: boolean;
  hideActionButtons: boolean;

  // 4. Metrics & Counters
  hideLikeCount: boolean;
  hideShareCount: boolean;
  hideCommentCount: boolean;

  // 5. Commercials & Distractions
  hideShop: boolean;
  hideAds: boolean;
  hideHeaderPromos: boolean; // Hide "Get Coins", "Get App", etc.

  // 6. LIVE Streams
  hideLiveChat: boolean;
  hideLiveGifts: boolean;

  // 7. Viral Filter in Following
  viralFilterEnabled: boolean;
  viralMinLikes: number;
  viralMinComments: number;

  // 8. Compact Following Grid in Sidebar
  showAllFollowingInSidebar: boolean;
}

/**
 * DEFAULT FOCUS & CREATOR MODE:
 * - Removes addictive algorithmic "For You" feed
 * - Removes comments, ads, promos, and like counters
 * - KEEPS: Followed creators (Following), Profile, and Upload
 */
export const DEFAULT_SETTINGS: TikTokUnhookSettings = {
  masterEnabled: true,
  theme: 'dark',
  language: 'en',

  // Feeds
  hideForYouFeed: true,
  hideExploreFeed: true,
  hideFollowingFeed: false,
  redirectToProfile: true,

  // Sidebar
  hideSuggestedAccounts: true,
  highlightFollowingAccounts: true,
  hideLiveSidebar: true,
  hidePlaylists: true,
  hideFundraisers: true,
  hideSidebarFooter: true,

  // Video & Comments
  hideComments: true,
  hideDescriptions: false,
  hideActionButtons: false,

  // Metrics
  hideLikeCount: false,
  hideShareCount: false,
  hideCommentCount: false,

  // Distractions & Commercials
  hideShop: true,
  hideAds: true,
  hideHeaderPromos: true,

  // LIVE
  hideLiveChat: true,
  hideLiveGifts: true,

  // Viral Filter
  viralFilterEnabled: true,
  viralMinLikes: 1000,
  viralMinComments: 20,

  // Compact Following
  showAllFollowingInSidebar: true,
};

const STORAGE_KEY = 'tiktok_unhook_settings';

export async function getSettings(): Promise<TikTokUnhookSettings> {
  try {
    if (typeof browser !== 'undefined' && browser.storage?.local) {
      const res = await browser.storage.local.get(STORAGE_KEY);
      return { ...DEFAULT_SETTINGS, ...(res[STORAGE_KEY] || {}) };
    } else if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get([STORAGE_KEY], (res) => {
          resolve({ ...DEFAULT_SETTINGS, ...(res?.[STORAGE_KEY] || {}) });
        });
      });
    }
  } catch (err) {
    console.error('[TikTok Unhook] Error reading settings:', err);
  }
  return DEFAULT_SETTINGS;
}

export async function saveSettings(settings: TikTokUnhookSettings): Promise<void> {
  try {
    if (typeof browser !== 'undefined' && browser.storage?.local) {
      await browser.storage.local.set({ [STORAGE_KEY]: settings });
    } else if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      await new Promise<void>((resolve) => {
        chrome.storage.local.set({ [STORAGE_KEY]: settings }, () => resolve());
      });
    }
  } catch (err) {
    console.error('[TikTok Unhook] Error saving settings:', err);
  }
}

export function onSettingsChange(callback: (newSettings: TikTokUnhookSettings) => void): () => void {
  const listener = (changes: Record<string, any>, areaName: string) => {
    if (areaName === 'local' && changes[STORAGE_KEY]) {
      const newSettings = { ...DEFAULT_SETTINGS, ...changes[STORAGE_KEY].newValue };
      callback(newSettings);
    }
  };

  if (typeof browser !== 'undefined' && browser.storage?.onChanged) {
    browser.storage.onChanged.addListener(listener);
    return () => browser.storage.onChanged.removeListener(listener);
  } else if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener(listener);
    return () => chrome.storage.onChanged.removeListener(listener);
  }
  return () => {};
}
